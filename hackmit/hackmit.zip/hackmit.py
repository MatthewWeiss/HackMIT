# -*- coding: utf-8 -*-
"""
Created on Sat Sep 15 13:00:01 2018

@author: Matthew
"""
import csv
import os
from pulp import *
import numpy as np
TEAMS=32
WEEKS=17
TEAM_INDICES=[i for i in range(TEAMS)]
WEEK_INDICES=[j for j in range(WEEKS)]
SCHEDFILE='NFL 2018-2019 Schedule.csv'
ELOFILE='2018 preseason elo.csv'
def load_data(filename):
    """Reads in the schedule dataset from a file. This should be used to read in a .csv file
    and scrape it"""
    f=open(filename,'r')
    if f.mode=='r':
        data=f.read()
        return data
def fix_data_s(data):
    """This reformats the data into a nice format. If a new data input format is used, this code
    can be reworked without affecting the rest"""
    data=data.split(',')
    for i in range(len(data)):
        item=data[i]
        if item[0]=="\n":
            data[i]=item[1:]
    return data

def build_schedule_dict(data):
    """Builds a dictionary of the schedule from the well formatted data"""
    sched_dict={}
    team_list=[]
    for i in range(TEAMS):
        sched_dict[data[i*(WEEKS+1)]]=data[i*(WEEKS+1)+1:(i+1)*(WEEKS+1)]
        team_list.append(data[i*(WEEKS+1)])
    return sched_dict, team_list
        
def set_up_schedule(filename):
    """Sets up the schedule"""
    return build_schedule_dict(fix_data_s(load_data(filename)))

def build_elo_dict(data):
    elo_dict={}
    for i in range(TEAMS):
        elo_dict[data[2*i]]=float(data[2*i+1])
    return elo_dict
        
def set_up_elo(filename):
    return build_elo_dict(fix_data_s(load_data(filename)))

def compute_home_win_prob(home,road, elo_dict, true_home=True):
    home_elo=elo_dict[home]
    road_elo=elo_dict[road]
    prob=1/(10**(-1*(home_elo-road_elo+65*true_home)/400)+1)
    return prob

def create_wp_dict(sched_dict,elo_dict):
    wp_dict={}
    for team in sched_dict:
        wp_dict[team]=[]
        for game in sched_dict[team]:
            if game=='BYE':
                logprob=-10
            elif game[0]=='@':
                logprob=np.log(1-compute_home_win_prob(game[1:],team,elo_dict))
            elif game[0]=='&':
                logprob=np.log(compute_home_win_prob(team,game[1:],elo_dict,False))
            else:
                logprob=np.log(compute_home_win_prob(team,game,elo_dict))
            wp_dict[team].append(logprob)
    return wp_dict
    
def write_wp_to_file(wp_dict, team_list):
    os.remove('wp.csv')
    with open('wp.csv','w+') as file:
        writer=csv.writer(file)
        for team in team_list:
            writer.writerow([team]+wp_dict[team])
            
def reformat(wp_dict, team_list):
    reformatted=[]
    for team in team_list:
        reformatted.append(wp_dict[team])
    return reformatted

def solver(wp_array, team_list, sched_dict):
    prob=pulp.LpProblem("Pickem",LpMaximize)
    xvars=LpVariable.dicts("Picked",[(i,j) for i in TEAM_INDICES for j in WEEK_INDICES],0,1,LpBinary)
    prob+=lpSum([xvars[(i,j)]*wp_array[i][j] for i in TEAM_INDICES for j in WEEK_INDICES])
    for j in range(WEEKS):      
        prob+=lpSum([xvars[(i,j)] for i in TEAM_INDICES])==1
    for i in range(TEAMS):
        prob+=lpSum([xvars[(i,j)] for j in WEEK_INDICES])<=1
    
    print(prob)
    
    prob.solve()
    for j in WEEK_INDICES:
        for i in TEAM_INDICES:
            if xvars[(i,j)].varValue==1:
                print("Week", j+1, "Pick", team_list[i], "playing", sched_dict[team_list[i]][j])
                
  


def main():
#    d=(load_data("2018 preseason elo.csv"))
#    d=d.split(',')
#    print(len(d))
    sched_dict,team_list=set_up_schedule(SCHEDFILE) 
    elo_dict=set_up_elo(ELOFILE)
    wp_dict=create_wp_dict(sched_dict,elo_dict)
    print(wp_dict)
    check=[sum(wp_dict[item]) for item in wp_dict]
    print(sum(check))
    write_wp_to_file(wp_dict,team_list)
    solver(reformat(wp_dict,team_list), team_list, sched_dict)

    
if __name__=='__main__':
    main()